namespace Transportation.Interfaces;

public interface IAirplanes
{
    string GetBrand { get; }

    string[] GetModels { get; }
}